import React, { useState, useEffect } from 'react';
import type { GameHook } from '../hooks/useGame';
import PowerMeter from '../components/PowerMeter';
import SignalReconstruction from '../components/SignalReconstruction';
import InvestigationPathSelection from '../components/InvestigationPathSelection';
import { ArtifactType } from '../engine/shared/enums';
import type { Memory } from '../engine/memory/types';
import { CorruptionSystem } from '../utils/corruption';

// Helper functions for artifact display
function getArtifactIcon(artifactType: ArtifactType): string {
  const icons = {
    SCIENTIFIC_REPORT: '📊',
    GOVERNMENT_DOCUMENT: '📋',
    PERSONAL_DIARY: '📖',
    AUDIO_TRANSCRIPT: '🎵',
    CULTURAL_RECORD: '🎭',
    HISTORICAL_ARTICLE: '📰',
    RESEARCH_PAPER: '🔬',
    LETTER: '✉️',
    PHOTOGRAPH: '📸',
    RECOVERED_TRANSMISSION: '📡',
  };
  return icons[artifactType] || '📄';
}

function formatArtifactType(artifactType: ArtifactType): string {
  return artifactType.replace(/_/g, ' ');
}

function getArtifactContent(memory: Memory): string {
  const contentMap: Record<ArtifactType, string> = {
    SCIENTIFIC_REPORT: `Research File: ${memory.title}\nClassification: Public Domain\nSummary: ${memory.summary}`,
    GOVERNMENT_DOCUMENT: `CLASSIFIED DOCUMENT\nProject: ${memory.title}\nClearance Level: █████\n\n${memory.summary}`,
    PERSONAL_DIARY: `Entry #${Math.floor(Math.random() * 1000) + 1}\n"${memory.summary}"\n\n[Personal thoughts partially illegible]`,
    AUDIO_TRANSCRIPT: `[AUDIO TRANSCRIPT - ${memory.era}]\n[QUALITY: ${memory.corruptionScore > 2 ? 'POOR' : 'GOOD'}]\n\n"${memory.summary}"\n\n[END TRANSMISSION]`,
    CULTURAL_RECORD: `Cultural Archive Entry\nPeriod: ${memory.era}\nSignificance: ${memory.summary}`,
    HISTORICAL_ARTICLE: `Historical Analysis: ${memory.title}\nEra: ${memory.era}\n\n${memory.summary}`,
    RESEARCH_PAPER: `Research Abstract\nTitle: ${memory.title}\nConclusion: ${memory.summary}`,
    LETTER: `Personal Correspondence\n\nDear Archive,\n\n${memory.summary}\n\n[Signature corrupted]`,
    PHOTOGRAPH: `[PHOTOGRAPH]\nLocation: Unknown\nDate: ${memory.era}\nDescription: ${memory.summary}`,
    RECOVERED_TRANSMISSION: `[SIGNAL RECOVERED]\nOrigin: Unknown\nTimestamp: ${memory.era}\n\nMessage: "${memory.summary}"\n\n[Signal lost]`,
  };
  return contentMap[memory.artifactType] || memory.summary;
}

export default function MemoryScreen({ game }: { game: GameHook }) {
  const [showReconstruction, setShowReconstruction] = useState(true);
  const [showPathSelection, setShowPathSelection] = useState(false);
  
  // Reset reconstruction when memory changes
  useEffect(() => {
    setShowReconstruction(true);
    setShowPathSelection(false);
  }, [game.memory?.id]);

  if (!game.memory) return null;

  // Show reconstruction animation first
  if (showReconstruction) {
    return (
      <SignalReconstruction
        memoryTitle={game.memory.title}
        onComplete={() => setShowReconstruction(false)}
      />
    );
  }

  // Show investigation path selection
  if (showPathSelection) {
    return (
      <InvestigationPathSelection
        memoryTitle={game.memory.title}
        currentPower={game.power}
        onSelectPath={(pathId) => {
          setShowPathSelection(false);
          game.investigateWithPath(pathId);
        }}
        onCancel={() => setShowPathSelection(false)}
      />
    );
  }

  return (
    <div style={{
      height: '100vh', display: 'flex', flexDirection: 'column',
      padding: 24, maxWidth: 640, margin: '0 auto',
      overflow: 'hidden',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <span style={{ fontSize: 10, color: '#4B5563', letterSpacing: 2, textTransform: 'uppercase' }}>
            Memory #{game.processed}
          </span>
          {game.connections.length > 0 && (
            <div style={{ marginTop: 6, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {game.connections.map((c, i) => (
                <span key={i} style={{
                  fontSize: 10, color: '#9B5DE5', letterSpacing: 0.5,
                  border: '1px solid rgba(155,93,229,0.2)', borderRadius: 4,
                  padding: '2px 8px',
                }}>
                  {c.label}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div style={{
          background: 'linear-gradient(135deg, #111627 0%, #0D1120 100%)',
          border: '1px solid rgba(108,203,255,0.12)',
          borderRadius: 12,
          padding: '32px 28px',
          display: 'flex',
          flexDirection: 'column',
          gap: 20,
          position: 'relative',
          overflow: 'hidden',
          opacity: 0,
          animation: 'fadeInUp 0.8s ease forwards',
        }}>
          <div style={{
            position: 'absolute', top: -80, right: -80, width: 200, height: 200,
            background: 'radial-gradient(circle, rgba(108,203,255,0.06) 0%, transparent 70%)',
            pointerEvents: 'none', borderRadius: '50%',
          }} />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 11, color: '#6B7280', letterSpacing: 1, textTransform: 'uppercase' }}>
              Year {game.memory.era} · {game.memory.category}
            </span>
          </div>

          <div>
            <h2 style={{ fontSize: 20, fontWeight: 500, color: '#F5F7FA', lineHeight: 1.3, marginBottom: 12 }}>
              {CorruptionSystem.corruptTitle(game.memory.title, game.memory.corruptionScore)}
            </h2>
            <p style={{ fontSize: 14, color: '#9CA3AF', lineHeight: 1.7 }}>
              {CorruptionSystem.corruptText(game.memory.description, game.memory.corruptionScore / 2)}
            </p>
            
            {/* Artifact Section */}
            <div style={{
              marginTop: 20,
              padding: 16,
              background: 'rgba(0,0,0,0.2)',
              borderRadius: 8,
              border: '1px solid rgba(108,203,255,0.1)'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                marginBottom: 12,
              }}>
                <span style={{
                  fontSize: 10,
                  color: '#6CCBFF',
                  letterSpacing: 1,
                  textTransform: 'uppercase',
                  fontWeight: 600,
                }}>
                  {getArtifactIcon(game.memory.artifactType)} {formatArtifactType(game.memory.artifactType)}
                </span>
                {game.memory.corruptionScore > 0 && (
                  <span style={{
                    fontSize: 9,
                    color: '#D62839',
                    background: 'rgba(214,40,57,0.15)',
                    padding: '2px 6px',
                    borderRadius: 3,
                    fontWeight: 700,
                  }}>
                    CORRUPTED
                  </span>
                )}
              </div>
              
              {/* Artifact Content */}
              <div style={{
                fontSize: 12,
                color: '#D1D5DB',
                fontFamily: "'SF Mono','Fira Code',monospace",
                lineHeight: 1.6,
              }}>
                {CorruptionSystem.corruptText(getArtifactContent(game.memory), game.memory.corruptionScore)}
              </div>
              
              {/* Corruption Fragments */}
              {game.memory.corruptionScore > 0 && (
                <div style={{
                  marginTop: 12,
                  padding: 8,
                  background: 'rgba(214,40,57,0.1)',
                  borderRadius: 4,
                  border: '1px solid rgba(214,40,57,0.2)'
                }}>
                  <div style={{
                    fontSize: 8,
                    color: '#D62839',
                    marginBottom: 4,
                    letterSpacing: 1,
                    textTransform: 'uppercase',
                  }}>
                    Corruption Detected
                  </div>
                  <div style={{
                    fontSize: 11,
                    color: '#F87171',
                    fontStyle: 'italic',
                  }}>
                    {CorruptionSystem.getRandomFragment()} - Archive integrity compromised.
                  </div>
                </div>
              )}
            </div>
          </div>

          <div style={{ marginTop: 'auto' }}>
            <div style={{ display: 'flex', gap: 12 }}>
              <button
                style={{
                  flex: 1, padding: '12px 24px', borderRadius: 8, fontSize: 12,
                  fontWeight: 600, letterSpacing: 1.5, textTransform: 'uppercase',
                  background: 'rgba(46,196,182,0.12)', color: '#2EC4B6',
                  border: '1px solid rgba(46,196,182,0.25)',
                  transition: 'all 0.2s',
                }}
                onClick={game.preserve}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(46,196,182,0.2)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'rgba(46,196,182,0.12)'; }}
              >
                Preserve
              </button>
              <button
                style={{
                  flex: 1, padding: '12px 24px', borderRadius: 8, fontSize: 12,
                  fontWeight: 600, letterSpacing: 1.5, textTransform: 'uppercase',
                  background: 'rgba(214,40,57,0.12)', color: '#D62839',
                  border: '1px solid rgba(214,40,57,0.25)',
                  transition: 'all 0.2s',
                }}
                onClick={game.discard}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(214,40,57,0.2)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'rgba(214,40,57,0.12)'; }}
              >
                Discard
              </button>
            </div>
            <button
              style={{
                width: '100%', marginTop: 8, padding: '12px 24px', borderRadius: 8,
                fontSize: 12, fontWeight: 600, letterSpacing: 1.5, textTransform: 'uppercase',
                background: 'rgba(108,203,255,0.08)', color: '#6CCBFF',
                border: '1px solid rgba(108,203,255,0.2)',
                transition: 'all 0.2s',
              }}
              onClick={() => setShowPathSelection(true)}
              onMouseEnter={e => { e.currentTarget.style.background = 'rgba(108,203,255,0.15)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'rgba(108,203,255,0.08)'; }}
            >
              Investigate
            </button>
          </div>
        </div>
      </div>

      <div style={{ width: '100%', marginTop: 20 }}>
        <PowerMeter current={game.power} total={100} />
      </div>

      {game.connections.length > 0 && (
        <div style={{
          marginTop: 12, padding: '8px 12px',
          background: 'rgba(155,93,229,0.05)', borderRadius: 6,
          border: '1px solid rgba(155,93,229,0.08)',
        }}>
          {game.connections.map((c, i) => (
            <div key={i} style={{ fontSize: 11, color: '#9CA3AF', lineHeight: 1.6 }}>
              <span style={{ color: '#9B5DE5' }}>{c.label}:</span> {c.description}
            </div>
          ))}
        </div>
      )}

      {game.message && (
        <div style={{
          position: 'fixed', bottom: 60, left: '50%', transform: 'translateX(-50%)',
          background: 'rgba(17,22,39,0.95)', border: '1px solid rgba(108,203,255,0.15)',
          borderRadius: 8, padding: '10px 24px',
          fontSize: 12, color: '#9CA3AF', letterSpacing: 1,
        }}>
          {game.message}
        </div>
      )}

      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
