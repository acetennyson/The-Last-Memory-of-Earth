import { CorruptionSystem } from '../utils/corruption';
import TypewriterText from '../components/TypewriterText';

interface Props {
  onStart: () => void;
}

export default function IntroScreen({ onStart }: Props) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: '100vh', padding: 40,
      textAlign: 'center',
    }}>
      <div style={{ fontSize: 10, color: '#6B7280', letterSpacing: 3, textTransform: 'uppercase', marginBottom: 24 }}>
        Archive Unit A-01
      </div>

      <h1 style={{
        fontSize: 26, fontWeight: 400, color: '#F5F7FA',
        letterSpacing: 1.5, maxWidth: 600, lineHeight: 1.5, marginBottom: 32,
      }}>
        The Last Memory of Earth
      </h1>

      <div style={{
        maxWidth: 520, textAlign: 'left', marginBottom: 40,
        fontFamily: "'SF Mono','Fira Code',monospace", fontSize: 12,
        color: '#9CA3AF', lineHeight: 2,
        border: '1px solid rgba(108,203,255,0.1)', borderRadius: 8, padding: 24,
      }}>
        <p style={{ marginBottom: 16 }}>
          <TypewriterText text="If you are reading this... humanity is gone." speed={40} />
        </p>
        <p style={{ marginBottom: 16 }}>
          <TypewriterText text="You are the final custodian of its memory." speed={40} delay={2000} />
        </p>
        <p style={{ marginBottom: 16 }}>
          <TypewriterText text={CorruptionSystem.corruptText("The Archive has suffered catastrophic corruption.", 2)} speed={30} delay={4000} />
        </p>
        <p style={{ marginBottom: 8 }}>
          <TypewriterText text="Your task is not to discover what happened. Your task is to decide what deserves to be remembered." speed={35} delay={6500} />
        </p>
        <div style={{ marginTop: 16, fontSize: 10, color: '#D62839', fontStyle: 'italic' }}>
          {CorruptionSystem.getRandomFragment()}
        </div>
      </div>

      <button
        style={{
          padding: '14px 48px', background: 'transparent',
          color: '#6CCBFF', border: '1px solid rgba(108,203,255,0.3)',
          borderRadius: 8, fontSize: 12, letterSpacing: 2,
          textTransform: 'uppercase', fontWeight: 600,
          transition: 'all 0.3s',
        }}
        onClick={onStart}
        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(108,203,255,0.1)'; e.currentTarget.style.borderColor = '#6CCBFF'; }}
        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = 'rgba(108,203,255,0.3)'; }}
      >
        Begin Archive Restoration
      </button>
    </div>
  );
}
