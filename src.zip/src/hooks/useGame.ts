import { useState, useCallback, useRef } from 'react';
import { GameEngine } from '../engine/GameEngine';
import type { GameContent, Memory, PlayerProfile, CivilizationResult, HistoryBook, Evidence, Contradiction } from '../engine';
import { memoryConnections, memoryIndex } from '../data/sampleContent';
import { corruptionFragments } from '../data/narrativeContent';

const FRAGS: Record<string, string[]> = {
  // Use rich corruption fragments from narrative content
  'mem_ai_004': corruptionFragments['cor_ai_001'],
  'mem_mars_002': corruptionFragments['cor_mars_001'],
  'mem_mars_003': corruptionFragments['cor_mars_002'],
  'mem_mars_004': corruptionFragments['cor_mars_003'],
  'mem_final_001': corruptionFragments['cor_final_001'],
  'mem_archive_001': corruptionFragments['cor_archive_001'],
};

enum Stage {
  BOOT, INTRO, MEMORY, INVESTIGATION, ENDING, HISTORY_BOOK, CORRUPTED
}

export function useGame(content: GameContent) {
  const engineRef = useRef(new GameEngine(content));
  const engine = engineRef.current;

  const [stage, setStage] = useState(Stage.BOOT);
  const [memory, setMemory] = useState<Memory | null>(null);
  const [profile, setProfile] = useState<PlayerProfile>(engine.state.session.profile);
  const [power, setPower] = useState(engine.state.session.powerRemaining);
  const [processed, setProcessed] = useState(0);
  const [evidenceRecords, setEvidenceRecords] = useState<Evidence[]>([]);
  const [contradictions, setContradictions] = useState<Contradiction[]>([]);
  const [ending, setEnding] = useState<{ civilization: CivilizationResult; book: HistoryBook } | null>(null);
  const [message, setMessage] = useState('');

  const [preservedCount, setPreservedCount] = useState(0);
  const [discardedCount, setDiscardedCount] = useState(0);
  const [investigationStep, setInvestigationStep] = useState(0);
  const [totalInvestigationSteps, setTotalInvestigationSteps] = useState(0);
  const [contradictionsRevealed, setContradictionsRevealed] = useState(false);
  const [connections, setConnections] = useState<{ label: string; description: string }[]>([]);
  const [corruptionFragments, setCorruptionFragments] = useState<string[]>([]);

  const sync = useCallback(() => {
    const s = engine.state;
    setProfile(s.session.profile);
    setPower(s.session.powerRemaining);
    setProcessed(s.session.processedMemoryIds.length);
  }, [engine]);

  const advance = useCallback(() => {
    sync();
    if (engine.canEnd() || engine.state.session.processedMemoryIds.length >= 10) {
      const end = engine.generateEnding() as any;
      setEnding({ civilization: end.civilization, book: end.book });
      setStage(Stage.ENDING);
      return;
    }
    const m = engine.loadNext(content.memories);
    if (m) {
      const processedCount = engine.state.session.processedMemoryIds.length;
      if (processedCount >= 5 && Math.random() < 0.6) {
        const mid = m.id;
        const frags = FRAGS[String(mid)];
        if (frags) {
          setCorruptionFragments(frags);
          setMemory(m);
          setStage(Stage.CORRUPTED);
          return;
        }
      }
      setMemory(m);
      setEvidenceRecords([]);
      setContradictions([]);
      setConnections([]);
      setInvestigationStep(0);
      setContradictionsRevealed(false);

      const mid = m.id;
      const idx = (k: string) => (memoryIndex as any)[k];
      const related = memoryConnections
        .filter(c => c.from === mid || c.to === mid)
        .map(c => ({
          label: c.type === 'contradicts' ? `Contradicts Memory #${idx(c.from === mid ? c.to : c.from)}` : `Caused by Memory #${idx(c.from === mid ? c.to : c.from)}`,
          description: c.description,
        }));
      setConnections(related);

      setStage(Stage.MEMORY);
    } else {
      const end = engine.generateEnding() as any;
      setEnding({ civilization: end.civilization, book: end.book });
      setStage(Stage.ENDING);
    }
  }, [engine, content.memories, sync]);

  const boot = useCallback(() => setStage(Stage.INTRO), []);
  const start = useCallback(() => {
    const m = engine.loadNext(content.memories);
    if (m) setMemory(m);
    sync();
    setStage(Stage.MEMORY);
  }, [engine, content.memories, sync]);

  const preserve = useCallback(() => {
    engine.preserve();
    setPreservedCount(c => c + 1);
    sync();
    setMessage('Memory preserved.');
    setTimeout(() => setMessage(''), 1200);
    setTimeout(() => advance(), 400);
  }, [engine, sync, advance]);

  const discard = useCallback(() => {
    engine.discard();
    setDiscardedCount(c => c + 1);
    sync();
    setMessage('Memory discarded.');
    setTimeout(() => setMessage(''), 1200);
    setTimeout(() => advance(), 400);
  }, [engine, sync, advance]);

  const investigate = useCallback(() => {
    const result = engine.investigate() as any;
    if (result) {
      const records = result.revelations?.map((r: any) => r.evidence as Evidence) || [];
      const contradictions = result.contradictions || [];
      setEvidenceRecords(records);
      setContradictions(contradictions);
      setContradictionsRevealed(false);
      setInvestigationStep(0);
      setTotalInvestigationSteps(records.length);
      setStage(Stage.INVESTIGATION);
      sync();
    } else {
      setMessage('Insufficient archive power.');
      setTimeout(() => setMessage(''), 1500);
    }
  }, [engine, sync]);

  const investigateWithPath = useCallback((pathId: string) => {
    const result = engine.investigate() as any;
    if (result) {
      const allRecords = result.revelations?.map((r: any) => r.evidence as Evidence) || [];
      
      // Filter evidence based on investigation path with more specific mappings
      const pathFilterMap: Record<string, string[]> = {
        'government': ['GOVERNMENT_DOCUMENT', 'SCIENTIFIC_RECORD', 'NEWS_REPORT'],
        'testimony': ['PERSONAL_DIARY', 'AUDIO_LOG'],
        'corporate': ['GOVERNMENT_DOCUMENT', 'NEWS_REPORT'], 
        'ai_logs': ['SCIENTIFIC_RECORD', 'AUDIO_LOG']
      };
      
      const allowedSources = pathFilterMap[pathId] || [];
      const filteredRecords = allowedSources.length > 0 
        ? allRecords.filter((record: Evidence) => allowedSources.includes(record.sourceType))
        : allRecords;
      
      // Ensure we always have at least one piece of evidence
      const records = filteredRecords.length > 0 ? filteredRecords : allRecords.slice(0, 1);
      
      const contradictions = result.contradictions || [];
      setEvidenceRecords(records);
      setContradictions(contradictions);
      setContradictionsRevealed(false);
      setInvestigationStep(0);
      setTotalInvestigationSteps(records.length);
      setStage(Stage.INVESTIGATION);
      sync();
      
      // Show path-specific message
      const pathMessages: Record<string, string> = {
        'government': 'Accessing classified government archives...',
        'testimony': 'Reviewing personal testimonies and survivor accounts...',
        'corporate': 'Scanning corporate databases and internal communications...',
        'ai_logs': 'Analyzing AI system logs and decision trees...'
      };
      setMessage(pathMessages[pathId] || 'Investigation initiated...');
      setTimeout(() => setMessage(''), 2000);
    } else {
      setMessage('Insufficient archive power.');
      setTimeout(() => setMessage(''), 1500);
    }
  }, [engine, sync]);

  const nextEvidenceStep = useCallback(() => {
    if (investigationStep < totalInvestigationSteps - 1) {
      setInvestigationStep(s => s + 1);
    } else if (contradictions.length > 0 && !contradictionsRevealed) {
      setContradictionsRevealed(true);
    }
  }, [investigationStep, totalInvestigationSteps, contradictions.length, contradictionsRevealed]);

  const backFromInvestigation = useCallback(() => {
    setStage(Stage.MEMORY);
    sync();
  }, [sync]);

  const continueFromCorruption = useCallback(() => {
    setMemory(memory);
    setEvidenceRecords([]);
    setContradictions([]);
    setConnections([]);
    setInvestigationStep(0);
    setContradictionsRevealed(false);

    const m = memory;
    if (m) {
      const mid = m.id;
      const idx = (k: string) => (memoryIndex as any)[k];
      const related = memoryConnections
        .filter(c => c.from === mid || c.to === mid)
        .map(c => ({
          label: c.type === 'contradicts' ? `Contradicts Memory #${idx(c.from === mid ? c.to : c.from)}` : `Caused by Memory #${idx(c.from === mid ? c.to : c.from)}`,
          description: c.description,
        }));
      setConnections(related);
    }

    setStage(Stage.MEMORY);
  }, [memory]);

  const viewHistoryBook = useCallback(() => setStage(Stage.HISTORY_BOOK), []);
  const restart = useCallback(() => window.location.reload(), []);

  return {
    stage, memory, profile, power, processed,
    evidenceRecords, contradictions, ending, message,
    preservedCount, discardedCount,
    investigationStep, totalInvestigationSteps, contradictionsRevealed,
    connections, corruptionFragments,
    Stage, boot, start, preserve, discard, investigate, investigateWithPath,
    nextEvidenceStep, backFromInvestigation,
    continueFromCorruption, viewHistoryBook, advance, restart,
  };
}

export type GameHook = ReturnType<typeof useGame>;
