import React from 'react';
import { useGame } from './hooks/useGame';
import { sampleContent } from './data/sampleContent';
import BootScreen from './pages/BootScreen';
import IntroScreen from './pages/IntroScreen';
import MemoryScreen from './pages/MemoryScreen';
import InvestigationScreen from './pages/InvestigationScreen';
import CorruptedScreen from './pages/CorruptedScreen';
import EndingScreen from './pages/EndingScreen';
import HistoryBookScreen from './pages/HistoryBookScreen';
import AmbientBackground from './components/AmbientBackground';

export default function App() {
  const game = useGame(sampleContent);

  const screens: Record<number, React.ReactNode> = {
    [game.Stage.BOOT]: <BootScreen onComplete={game.boot} />,
    [game.Stage.INTRO]: <IntroScreen onStart={game.start} />,
    [game.Stage.MEMORY]: <MemoryScreen game={game} />,
    [game.Stage.INVESTIGATION]: <InvestigationScreen game={game} />,
    [game.Stage.CORRUPTED]: <CorruptedScreen game={game} />,
    [game.Stage.ENDING]: <EndingScreen game={game} />,
    [game.Stage.HISTORY_BOOK]: <HistoryBookScreen game={game} />,
  };

  const isCorrupted = game.stage === game.Stage.CORRUPTED;
  const intensity = game.power < 25 ? 2 : 1;

  return (
    <>
      <AmbientBackground intensity={intensity} corruption={isCorrupted} />
      {screens[game.stage] || null}
    </>
  );
}
